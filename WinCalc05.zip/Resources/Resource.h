#if !defined (RESOURCE_H)
#define RESOURCE_H
// Bartosz Milewski (c) 2000

#define IDI_MAIN	101

#define IDD_ABOUT	102
#define IDD_SAVE	103
#define IDD_LOAD	104

#define IDC_EDIT	201
#define IDC_LIST	202
#define IDC_STATICPATH 203

#endif
