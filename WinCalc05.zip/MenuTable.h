#if !defined (MENUTABLE_H)
#define MENUTABLE_H
// Bartosz Milewski (c) 2000
#include "Menu.h"

namespace Menu
{
	extern BarItem const barItems [];
}

#endif
